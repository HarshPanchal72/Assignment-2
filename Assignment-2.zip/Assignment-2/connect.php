<?php
$firstName = filter_input(INPUT_POST,'firstname');
$lastName = filter_input(INPUT_POST,'lastname');
$Country = filter_input(INPUT_POST,'country');
$Subject = filter_input(INPUT_POST,'subject');

// Database connection
$conn = new mysqli('localhost', 'root', '', 'feedback details');
if ($conn->connect_error) {
    echo "Connection Failed: " . $conn->connect_error;
    die();
} else {
    $stmt = $conn->prepare("INSERT INTO `form details` (`firstName`, `lastName`, `Country`, `Subject`) VALUES (?, ?, ?, ?)");
    if ($stmt === false) {
        echo "Prepare failed: " . $conn->error;
        die();
    }
    
    $stmt->bind_param("ssss", $firstName, $lastName, $Country, $Subject);
    if ($stmt->execute()) {
        echo "Data submitted successfully...";
    } else {
        echo "Error: " . $stmt->error;
    }
    
    $stmt->close();
    $conn->close();
}
?>
